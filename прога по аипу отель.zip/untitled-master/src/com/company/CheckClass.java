package com.company;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

public class CheckClass {
    private static final Logger log = LogManager.getLogger(SearchClass.class);

    public boolean isNotNumberOfRoomAlreadyCreated(int numberOfRoom, Map roomMap) {
        log.info("Произведена проверка на наличие введенного номера комнаты");
        return !roomMap.containsKey(numberOfRoom);
    }
}

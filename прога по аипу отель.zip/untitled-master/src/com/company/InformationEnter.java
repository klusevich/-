package com.company;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Scanner;

public class InformationEnter {
    private int numberOfBeds;
    private String nameOfGuest;
    private int cost;
    private int searchNumberOfBeds;
    private int searchNumberOfRoom;
    private int matchNumberOfRoom;
    private String searchNameOfGuest;
    private int searchCost;
    private String action;
    Scanner in = new Scanner(System.in);
    Scanner scanner = new Scanner(System.in);
    HotelRoom hotelRoom = new HotelRoom();
    private static final Logger log = LogManager.getLogger(SearchClass.class);

    public void enterRoom() {
        System.out.println("Введите количество кроватей: ");
        numberOfBeds = scanner.nextInt();
        System.out.println("Введите имя постояльца: ");
        nameOfGuest = in.nextLine();
        System.out.println("Введите стоимость номера: ");
        cost = scanner.nextInt();
        log.info("Произошел ввод информации о номере");
    }

    public String enterAction() {
        System.out.println("Введите желаемое действие: ");
        System.out.println("Добавление номера");
        System.out.println("Просмотр всех номеров");
        System.out.println("Поиск номера по номеру комнаты");
        System.out.println("Поиск номера по количеству кроватей");
        System.out.println("Поиск номера по имени постояльца");
        System.out.println("Поиск номера по стоимости номера");
        action = in.nextLine();
        log.info("Выведено меню выбора действия");
        return action;
    }

    public int enterMatchNumberOfRoom() {
        System.out.println("Введите номер комнаты: ");
        matchNumberOfRoom = scanner.nextInt();
        log.info("Произведен ввод номера комнаты");
        return matchNumberOfRoom;
    }

    public int enterSearchNumberOfRoom() {
        System.out.println("Введите номер комнаты для поиска: ");
        searchNumberOfRoom = scanner.nextInt();
        log.info("Произведен ввод номера комнаты для поиска");
        return searchNumberOfRoom;
    }

    public int enterSearchNumberOfBeds() {
        System.out.println("Введите количество кроватей для поиска: ");
        searchNumberOfBeds = scanner.nextInt();
        log.info("Произведен ввод количества кроватей для поиска");
        return searchNumberOfBeds;
    }

    public String enterSearchNameOfGuest() {
        System.out.println("Введите имя постояльца для поиска: ");
        searchNameOfGuest = in.nextLine();
        log.info("Произведен ввод имени постояльца для поиска");
        return searchNameOfGuest;
    }

    public int enterSearchCost() {
        System.out.println("Введите стоимость номера для поиска: ");
        searchCost = scanner.nextInt();
        log.info("Произведен ввод стоимости номера для поиска");
        return searchCost;
    }

    public int getNumberOfBeds() {
        return numberOfBeds;
    }

    public String getNameOfGuest() {
        return nameOfGuest;
    }

    public int getCost() {
        return cost;
    }
}

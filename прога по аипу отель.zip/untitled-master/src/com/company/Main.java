package com.company;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class Main {
    private static InformationEnter informationEnter = new InformationEnter();
    private static SearchClass searchClass = new SearchClass();
    private static final Logger log = LogManager.getLogger(Main.class);

    public static void main(String[] args) throws IOException {
        log.info("Выполнение программы началось");
        searchClass.createRoomMap();
        while (true) {
            switch (informationEnter.enterAction()) {
                case "Добавление номера":
                    searchClass.addNewRoom();
                    break;
                case "Просмотр всех номеров":
                    System.out.println(searchClass.getRoomMap());
                    break;
                case "Поиск номера по номеру комнаты":
                    int searchNumberOfRoom = informationEnter.enterSearchNumberOfRoom();
                    searchClass.searchByNumberOfRoom(searchNumberOfRoom);
                    break;
                case "Поиск номера по количеству кроватей":
                    int searchNumberOfBeds = informationEnter.enterSearchNumberOfBeds();
                    searchClass.searchByNumberOfBeds(searchNumberOfBeds);
                    break;
                case "Поиск номера по имени постояльца":
                    String searchNameOfGuest = informationEnter.enterSearchNameOfGuest();
                    searchClass.searchByNameOfGuest(searchNameOfGuest);
                    break;
                case "Поиск номера по стоимости номера":
                    int searchCost = informationEnter.enterSearchCost();
                    searchClass.searchByCost(searchCost);
                    break;
                default:
                    System.out.println("Неверное действие");
                    log.info("Выбрана неверное действие");
                    break;
            }
        }
    }
}

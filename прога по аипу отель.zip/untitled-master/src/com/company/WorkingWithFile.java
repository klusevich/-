package com.company;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WorkingWithFile {
    private static final String READ_PATH = "./src/com/company/resources/Hotel.txt";
    private static final String WRITE_PATH = "./src/com/company/resources/Hotel.txt";
    private static Gson gson = new GsonBuilder().create();
    private static final Logger log = LogManager.getLogger(WorkingWithFile.class);

    public String[] readFromFileByLines() throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader(READ_PATH));
        String line;
        List<String> lines = new ArrayList<>();
        while ((line = bufferedReader.readLine()) != null) {
            lines.add(line);
        }
        log.info("Произошло чтение из файла");
        return lines.toArray(new String[lines.size()]);
    }

    public static void writeIntoFile(HotelRoom hotelRoom) throws IOException {
        try (FileWriter fileWriter = new FileWriter(WRITE_PATH, true)) {
            String json = gson.toJson(hotelRoom);
            fileWriter.write(json + "\n");
        }
        log.info("Произошла запись в файл");
    }
}

package com.company;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Converter {
    private static final Logger log = LogManager.getLogger(SearchClass.class);

    public static HotelRoom JSONtoPOJO (String json) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        log.info("JSON преобразован в обьект Java");
        return gson.fromJson(json, HotelRoom.class);
    }
}
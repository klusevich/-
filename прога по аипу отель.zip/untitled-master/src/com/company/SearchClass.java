package com.company;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SearchClass {
    private Map<Integer, HotelRoom> roomMap = new HashMap<>();
    private WorkingWithFile workingWithFile = new WorkingWithFile();
    private InformationEnter informationEnter = new InformationEnter();
    private CheckClass checkClass = new CheckClass();
    private static final Logger log = LogManager.getLogger(SearchClass.class);

    public void createRoomMap() throws IOException {
        String[] linesAsArray = workingWithFile.readFromFileByLines();
        for (String json : linesAsArray){
            HotelRoom hotelRoom = Converter.JSONtoPOJO(json);
            roomMap.put(hotelRoom.getNumberOfRoom(), hotelRoom);
        }
        log.info("Хэш-карта создана");
    }

    public void addNewRoom() throws IOException {
        HotelRoom hotelRoom = new HotelRoom();
        int numberOfRoom = informationEnter.enterMatchNumberOfRoom();
        if (checkClass.isNotNumberOfRoomAlreadyCreated(numberOfRoom, roomMap)) {
            informationEnter.enterRoom();
            hotelRoom.setNumberOfRoom(numberOfRoom);
            hotelRoom.setNumberOfBeds(informationEnter.getNumberOfBeds());
            hotelRoom.setNameOfGuest(informationEnter.getNameOfGuest());
            hotelRoom.setCost(informationEnter.getCost());
            roomMap.put(numberOfRoom, hotelRoom);
            WorkingWithFile.writeIntoFile(hotelRoom);
            log.info("Новый номер добавлен");
        } else {
            System.out.println("Комната с таким номером уже существует");
            log.info("Комната с таким номером уже существует");
        }
    }

    public void searchByNumberOfRoom(int searchNumberOfRoom) {
        if (roomMap.containsKey(searchNumberOfRoom)) {
            System.out.println(roomMap.get(searchNumberOfRoom));
            log.info("Поиск по номеру комнаты выполнен");
        } else {
            System.out.println("Комнаты с номером " + searchNumberOfRoom + " не существует");
            log.info("Комната с введенным номером не существует");
        }
    }

    public void searchByNameOfGuest(String searchNameOfGuest) {
        Iterator<Map.Entry<Integer, HotelRoom>> entries = roomMap.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<Integer, HotelRoom> entry = entries.next();
            if (entry.getValue().getNameOfGuest().equals(searchNameOfGuest)) {
                System.out.println(roomMap.get(entry.getKey()));
            }
        }
        log.info("Поиск по имени постояльца выполнен");
    }

    public void searchByNumberOfBeds(int searchNumberOfBeds) {
        Iterator<Map.Entry<Integer, HotelRoom>> entries = roomMap.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<Integer, HotelRoom> entry = entries.next();
            if (entry.getValue().getNumberOfBeds() == searchNumberOfBeds) {
                System.out.println(roomMap.get(entry.getKey()));
            }
        }
        log.info("Поиск по количеству кроватей выполнен");
    }

    public void searchByCost(int searchCost) {
        Iterator<Map.Entry<Integer, HotelRoom>> entries = roomMap.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<Integer, HotelRoom> entry = entries.next();
            if (entry.getValue().getCost() == searchCost) {
                System.out.println(roomMap.get(entry.getKey()));
            }
        }
        log.info("Поиск по стоимости номера выполнен");
    }

    public Map<Integer, HotelRoom> getRoomMap() {
        return roomMap;
    }
}
